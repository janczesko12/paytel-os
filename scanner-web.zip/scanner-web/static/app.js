const codeReader = new ZXing.BrowserMultiFormatReader();

const video = document.getElementById("video");
const status = document.getElementById("status");
const nameBox = document.getElementById("name");
const priceBox = document.getElementById("price");
alert("app.js działa");
let lastCode = "";
let lastTime = 0;

async function sendBarcode(barcode){

    try{

        const response = await fetch("/scan",{
            method:"POST",
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify({
                barcode:barcode
            })
        });

        const data = await response.json();

        if(data.success){

            nameBox.innerText = data.name;
            priceBox.innerText = data.price.toFixed(2)+" zł";

            status.innerText="✅ Zeskanowano";

            if(navigator.vibrate){
                navigator.vibrate(120);
            }

        }else{

            nameBox.innerText="Nie znaleziono produktu";
            priceBox.innerText="";
            status.innerText="❌ Nie znaleziono";

        }

    }catch(e){

        status.innerText="Błąd połączenia";

        console.log(e);

    }

}

codeReader.decodeFromVideoDevice(
    null,
    video,
    (result,err)=>{

        if(result){

            const barcode=result.getText();

            const now=Date.now();

            if(barcode===lastCode && now-lastTime<1000){
                return;
            }

            lastCode=barcode;
            lastTime=now;

            status.innerText=barcode;

            sendBarcode(barcode);

        }

    }
);